from Main_Bank.Operations import Create as C
from Main_Bank.Operations import ListAcc as L
from Main_Bank.Operations import AccBal as B
from Main_Bank.Operations import AccDeposit as AD
from Main_Bank.Operations import AccWith as W
from Main_Bank.Operations import DeleteAcc as D
from Main_Bank.Operations import AccUpdate as U
from Main_Bank.Operations import AccDet as A
while True:
    print(
        '''
        Greetings To The User
        
        Choose an option from the following:-
        
        1.Create A New Account
        2.View List Of User accounts
        3.View Account Balance
        4.Deposit Amount
        5.Withdrawal amount
        6.Delete An Account
        7.Update An Account
        8.Display Bank Accounts 
        9.Exit
        
        "Display Bank Accounts,Delete An Account Are Accessed By Only Authorized Bank Employees"
        ''')

    ch = int(input())

    if ch == 1:
        print("-------------------------------------------------")
        t = C.user_insert()
        if t == 0:
            break
    elif ch == 2:
        print("-------------------------------------------------")
        L.List_Acc()
    elif ch == 3:
        print("-------------------------------------------------")
        B.Acc_Bal()
    elif ch == 4:
        print("-------------------------------------------------")
        AD.Amnt_Deposit()
    elif ch == 5:
        print("-------------------------------------------------")
        if((W.Acc_Withdraw()) == 0) :
            print("Insufficient Balance, cannot withdraw  ")

    elif ch == 6:
        print("-------------------------------------------------")
        D.Acc_delete()
    elif ch == 7:
        print("-------------------------------------------------")
        r = U.data_Update()
        if r == 0:
            break
    elif ch == 8:
        print("-------------------------------------------------")
        A.Bank_Acc()
    elif ch == 9:
        break