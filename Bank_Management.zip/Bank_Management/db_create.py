import sqlite3 as sq
"Bank.db"
con = sq.connect("Bank.db");
query='''
 create table user(Name text not null, Password text primary key, Date_Of_Birth Date , Date_Of_Account_created Date not null, Address text, Mobile_Number int not null, Balance real not null)
'''
con.execute(query)
con.commit()
