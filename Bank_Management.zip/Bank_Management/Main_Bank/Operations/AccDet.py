import sqlite3 as sq
con = sq.connect("Bank.db")
def Bank_Acc():
    bpwd = 1234
    bank_password = int(input("enter the bank password"))
    if bank_password == bpwd:
        print("user account data")
        query = '''
            select * from user
            '''
        de = con.execute(query)
        for i in de:
            print(i)
        print(""
              "user bank account data"
              "")
        query = '''
                    select * from bank_table
                    '''
        de = con.execute(query)
        for i in de:
            print(i)
        con.commit()