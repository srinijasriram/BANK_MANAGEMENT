import sqlite3 as sq
import datetime
con = sq.connect("Bank.db")

def data_Update():
    print("This Data Must Be Updated By Bank Authorized Employees ")
    p = int(input("Enter Bank Password  "))
    if p == 1234:
        print('''
           Enter Your Choice To Update
           1. Name
           2. Password
           3. Date_Of_Birth
           4. Date_Of_Account_created
           5. Address
           6. Mobile_Number
           7. Balance
           8. Account_Number
           9. return
        ''')
        q = int(input())
        if q == 1 :
            n = input("Enter The Name  ")
            p = input("Enter User Password  ")
            con.execute('''
                 update user set Name = ? where Password == ?
            ''', (n, p))
            con.execute('''
                update bank_table set UserName = ? where User_Password == ?
            ''', (n, p))
        elif q == 2 :
            o = input("Enter Old Password  ")
            p = input("Enter New Password  ")
            con.execute('''
               update user set Password = ? where Password == ?
            ''', (p, o))
            con.execute('''
               update bank_table set User_Password = ? where User_Password == ?
            ''', (p, o))
        elif q == 3 :
            p = input("Enter User Password  ")
            ud = input("Enter Your Correct Date_Of_Birth in yyyy-mm-dd formate ")
            try:
                datetime.datetime.strptime(ud, '%Y-%m-%d')
            except ValueError:
                print("You Should Enter The Date in formate of yyyy-mm-dd")
                return 0
            con.execute('''
                           update user set Date_Of_Birth = ? where Password == ?
                        ''', (ud, p))
        elif q == 4 :
            p = input("Enter User Password  ")
            ad = input("Enter Date_Of_Account_created in yyyy-mm-dd formate ")
            try:
                datetime.datetime.strptime(ad, '%Y-%m-%d')
            except ValueError:
                print("You Should Enter The Date in formate of yyyy-mm-dd")
                return 0
            con.execute('''
                         update user set Date_Of_Account_created = ? where Password == ?
                        ''', (ad, p))
        elif q == 5 :
            p = input("Enter User Password  ")
            a = input("Enter The Address  ")
            con.execute('''
               update user set Address = ? where Password == ?
            ''', (a, p))
        elif q == 6:
            p = input("Enter User Password  ")
            m = input("Enter The Mobile_Number  ")
            con.execute('''
                           update user set Mobile_Number = ? where Password == ?
                        ''', (m, p))
        elif q == 7 :
            p = input("Enter User Password  ")
            b = float(input("Enter The Balance  "))
            con.execute('''
                            update user set Balance = ? where Password == ?
                        ''', (b, p))
        elif q == 8 :
            p = input("Enter User Password  ")
            an = input("Enter The Account_Number  ")
            con.execute('''
                            update bank_table set Account_Number = ? where User_Password == ?
                        ''', (an, p))
        elif q == 9:
            return 1
        con.commit()
        return 1
    else :
        return 0
