import sqlite3 as sq
con = sq.connect("Bank.db")
def Acc_delete():
    bpwd = 1234
    bank_password = int(input("enter the bank password"))
    if bank_password == bpwd:
        pw = input("Enter The Password Of Account")
        con.execute(''' delete from user where Password = ? ''', [pw])
        con.execute('''delete from bank_table where User_Password = ? ''', [pw])
        con.commit()
    else:
        print("Wrong Password Of Bank Entered, So You Cannot Delete The Data Of User")
        return