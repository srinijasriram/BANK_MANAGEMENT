import sqlite3 as sq
con = sq.connect("Bank.db")
def List_Acc():
    a = int(input('''
        Enter 
        1. For One Particular User Account 
        2. For All 
    '''))
    if a == 1:
        p = input("Enter Password ")
        de = con.execute('''
                select Name,Date_Of_Birth, Date_Of_Account_created, Address, Mobile_Number, Balance, b.Account_Number from user, bank_table b where b.User_Password == ? and Password == ?
            ''',(p, p))
        for i in de:
            print(i)
    elif a == 2 :
        de = con.execute('''
            select Name,Date_Of_Birth, Date_Of_Account_created, Address, Mobile_Number, Balance, b.Account_Number from user, bank_table b where b.User_Password == Password
        ''')
        for i in de:
            print(i)
    con.commit()
    return