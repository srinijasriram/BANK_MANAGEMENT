import sqlite3 as sq
con = sq.connect("Bank.db")
c = con.cursor()
def Acc_Bal():
    n = input("Enter User_Name  ")
    p = input("Enter Password  ")
    de = c.execute('''
        select Balance from user where Name == ? and Password == ?
    ''', (n, p))
    de = c.fetchall()
    print("Balance In {} Account Is {}".format(n, de[0][0]))
    con.commit()
    return
