import sqlite3 as sq
con = sq.connect("Bank.db")
c = con.cursor()
def Amnt_Deposit():
    p = input("Enter The Password  ")
    a = float(input("Enter The Amount To Deposit  "))
    con.execute('''
        update user set Balance = Balance + ? where Password = ?
    ''', (a, p))
    c.execute('''
    select Balance from user where Password == ?
    ''', [p])
    de=c.fetchall()
    print("Total Balance Is {}".format(de[0][0]))
    con.commit()
