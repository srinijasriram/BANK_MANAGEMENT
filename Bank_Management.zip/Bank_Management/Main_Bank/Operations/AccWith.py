import sqlite3 as sq
con = sq.connect("Bank.db")
c = con.cursor()
def Acc_Withdraw():

    p = input("Enter User Password  ")
    a = float(input("Enter The Amount To Withdraw  "))
    c.execute('''
    select Balance from user where Password == ?
    ''', [p])
    de=c.fetchall()
    if (de[0][0] - a) <= 0:
        return 0
    else:
        con.execute('''
            update user set Balance = Balance - ? where Password = ?
        ''', (a, p))
        c.execute('''
            select Balance from user where Password == ?
            ''', [p])
        de = c.fetchall()
        print("Total Balance Is {}".format(de[0][0]))
        con.commit()
        return 1


