import sqlite3 as sq
import datetime
con = sq.connect("Bank.db")
def user_insert():
    n = input("Enter Your Name  ")
    p = input("Enter The Password For Your Account  ")
    ud = input("Enter Your Correct Date_Of_Birth in yyyy-mm-dd formate ")
    try:
        datetime.datetime.strptime(ud, '%Y-%m-%d')
    except ValueError:
        print("You Should Enter The Date in formate of yyyy-mm-dd")
        return 0
    ad = input("Enter Date_Of_Account_created in yyyy-mm-dd formate ")
    try:
        datetime.datetime.strptime(ad, '%Y-%m-%d')
    except ValueError:
        print("You Should Enter The Date in formate of yyyy-mm-dd")
        return 0
    a = input("Enter Your Address  ")
    m = int(input("Enter Your Mobile Number  "))
    bal = int(input("Enter Amount to deposit  "))

    data = {}

    data['name'] = n
    data['pwd'] = p
    data['dob'] = ud
    data['doa'] = ad
    data['address'] = a
    data['mobile'] = m
    data['balan'] = bal

    con.execute(
        '''
          insert into user(Name,Password,Date_Of_Birth,Date_Of_Account_created,Address,Mobile_Number,Balance) values(?,?,?,?,?,?,?)
        ''', (data.get('name'), data.get('pwd'), data.get('dob'), data.get('doa'), data.get('address'), data.get('mobile'), data.get('balan'))
    )

    print("This Details Must Be Enter By The Bank Employees")
    bpwd = 1234
    bank_password = int(input("enter the bank password"))
    if bank_password == bpwd:
        print("Welcome to Bank Employee")
        acc = input("Enter Valid Account Number For The User {}".format(n))
        data['acco'] = acc
        con.execute('''
           insert into bank_table(Account_Number,UserName,User_Password) values(?,?,?)
        ''', (data.get('acco'), data.get('name'), data.get('pwd'))
        )
    else:
        print("Your Not Authorized Bank Employee, So The Data Of User {} Is Not Created".format(n))
        con.execute( '''delete from user where Password = ?'''[p])

    con.commit()
    return 1

