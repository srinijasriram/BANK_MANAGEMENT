import sqlite3 as sq
con = sq.connect("Bank.db")
query='''
 create table bank_table(Account_Number text primary key,UserName text not null,User_Password text not null,FOREIGN KEY(User_Password) REFERENCES user(Password) )
'''
con.execute(query)
con.commit()